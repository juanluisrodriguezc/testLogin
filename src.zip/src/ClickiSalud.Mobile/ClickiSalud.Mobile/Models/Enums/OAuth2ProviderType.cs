﻿using System;
namespace ClickiSalud.Mobile.Models.Enums
{
    public enum OAuth2ProviderType
    {
        LOCAL = 0,
        FACEBOOK = 1,
        GOOGLE = 2
    }
}
