﻿using System;

namespace DTO
{
    public class ClientDto
    {
        /// <summary>
        /// Register key
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Client name
        /// </summary>
        public string Name { get; set; }
    }
}
