﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Response
{
    public class Preguntas
    {
        public List<Pregunta> preguntas { get; set; }
    }
}
