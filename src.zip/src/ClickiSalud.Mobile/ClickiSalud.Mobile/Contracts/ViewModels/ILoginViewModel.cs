﻿using System;
using ClickiSalud.Mobile.Models.Enums;

namespace ClickiSalud.Mobile.Contracts.ViewModels
{
    public interface ILoginViewModel
    {
        void LoginLocalOrProvider(OAuth2ProviderType oAuth2ProviderType);
    }
}
