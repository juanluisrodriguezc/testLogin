﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;
using WebApi.Services.Contracts;

namespace WebApi.Services.Mocks
{
    public class MockMessageService : IMessageService
    {
        private List<Message> messages;

        public MockMessageService()
        {
            messages = new List<Message>();
            for (int i = 0; i < 5; i++)
            {
                messages.Add(new Message() { Id = Guid.NewGuid().ToString(), Name = new Random().Next(33333, 99999).ToString() });
            }
        }

        public bool CreateMessage(Message message)
        {
            messages.Add(message);
            return true;
        }

        public bool DeleteMessage(string messageId)
        {
            var message = GetMessage(messageId);
            if (message == null)
                return false;
            messages.Remove(message);
            return true;
        }

        public Message GetMessage(string messageId)
        {
            return messages.SingleOrDefault(x => x.Id == messageId);
        }

        public List<Message> GetMessages()
        {
            return messages;
        }

        public bool UpdateMessage(Message messageToUpdate)
        {
            var exists = GetMessage(messageToUpdate.Id);
            if (exists == null)
                return false;
            var index = messages.FindIndex(a => a.Id == messageToUpdate.Id);
            messages[index] = messageToUpdate;
            return true;
        }
    }
}
