﻿using Android.App;
using Android.Content.PM;
using MvvmCross.Forms.Platforms.Android.Views;
using MvvmCross.Forms.Platforms.Android.Core;
using Android.OS;
using MvvmCross.Platforms.Android.Core;
using MvvmCross;
using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.Droid.Services;

namespace ClickiSalud.Mobile.Droid
{
    [Activity(Label = "ClickiSalud.Mobile", Icon = "@mipmap/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : MvxFormsAppCompatActivity<MvxFormsAndroidSetup<App, UI.App>, App, UI.App>
    {
        protected override void OnCreate(Bundle bundle)
        {
            global::Xamarin.Auth.Presenters.XamarinAndroid.AuthenticationConfiguration.Init(this,bundle);

            MvxAndroidSetupSingleton.EnsureSingletonAvailable(Application.Context)
                                    .EnsureInitialized();

            RegisterServices();

            base.OnCreate(bundle);
        }

        private void RegisterServices()
        {
            Mvx.IoCProvider.RegisterSingleton<IDialogService>(() => new DialogService());
        }
    }
}