﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DTO.Request
{
    public class ValidateAccountRequest
    {
        public string email { get; set; }
        public string keyToMail { get; set; }
    }
}
