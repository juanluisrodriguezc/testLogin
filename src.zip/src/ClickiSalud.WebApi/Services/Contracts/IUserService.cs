﻿using System;
using DTO.Enums;
using WebApi.Entities;

namespace WebApi.Services.Contracts
{
    public interface IUserService
    {
        Guid CreateUser(User user);
        User ValidateUser(string email, string pass);
        bool ValidateAccount(string email, string keyToMail);
        bool ForgotPass(string email);
        Guid CreateNewProfile(string email, ProviderEnum provider);
    }
}
