﻿using AutoMapper;
using DTO.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;
using WebApi.Services.Contracts;

namespace WebApi.Services.Mocks
{
    public class MockUserService : IUserService
    {
       private List<User> _users;

        public MockUserService()
        {
            _users = new List<User>();
        }
        public Guid CreateUser(User user)
        {
            _users.Add(user);
            return user.Id;
        }

        public bool ForgotPass(string email)
        {
            if (_users.Any(a => a.Email == email))
                return true;
            return false;
        }

        public bool ValidateAccount(string email, string keyToMail)
        {
            if (_users.Any(a => a.Email == email && a.KeyToMail == keyToMail))
                return true;
            return false;
        }

        public User ValidateUser(string email, string pass)
        {
            return _users.Where(a => a.Email == email && a.Password == pass).SingleOrDefault();
        }

        public Guid CreateNewProfile(string email, ProviderEnum provider)
        {
            var newUser = new User() { Email = email, Proveedor = provider };
            _users.Add(newUser);
            return newUser.Id;
        }
    }
}
