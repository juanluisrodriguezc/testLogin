﻿using ClickiSalud.Mobile.Models.Enums;

namespace ClickiSalud.Mobile.Models
{
    public class LoginProviderResponse
    {
        public OAuth2ProviderType ProviderType { get; set; }
        public FacebookLoginModel FacebookLogin { get; set; }
        public GoogleLoginModel GoogleLogin { get; set; }
    }

    public class LoginModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
    }

    public class GoogleLoginModel : LoginModel
    {
        public string picture { get; set; }
        public string family_name { get; set; }
    }

    public class FacebookLoginModel : LoginModel
    {
        public Picture picture { get; set; }
    }

    public class Picture
    {
        public Data Data { get; set; }
    }

    public class Data
    {
        public bool IsSilhouette { get; set; }
        public string Url { get; set; }
    }
}