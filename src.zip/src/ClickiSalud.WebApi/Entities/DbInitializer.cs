﻿using System;
using System.Linq;
using WebApi.Services.Contracts;

namespace WebApi.Entities
{
    /// <summary>
    /// Database initializer
    /// </summary>
    public static class DbInitializer
    {
        /// <summary>
        /// Seed tables data
        /// </summary>
        /// <param name="dbContext">Db context</param>
        /// <param name="telemetryService">Service for report exception</param>
        public static void Seed(AppDbContext dbContext, ITelemetryService telemetryService)
        {
            if(dbContext is null)
                throw new ArgumentNullException(nameof(dbContext));

            if (telemetryService is null)
                throw new ArgumentNullException(nameof(telemetryService));
            
            try
            {
                if (!dbContext.Clients.Any())
                {
                    dbContext.Clients.AddRange(new Client { Name = "CargoBrain" }, 
                                               new Client { Name = "bSide" });

                    dbContext.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                telemetryService.ReportException(ex);                
            }
        }
    }
}
