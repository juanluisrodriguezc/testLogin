﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApi.Entities
{
    /// <summary>
    /// Client database entity
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Register key
        /// </summary>        
        public Guid Key { get; set; }

        /// <summary>
        /// Identifier
        /// </summary>
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Client name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Intialize values
        /// </summary>
        public Client()
        {
            Key = Guid.NewGuid();
        }
    }
}
