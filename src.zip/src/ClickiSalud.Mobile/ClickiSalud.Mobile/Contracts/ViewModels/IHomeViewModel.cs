﻿namespace ClickiSalud.Mobile.Contracts.ViewModels
{
    public interface IHomeViewModel
    {
    }
}
