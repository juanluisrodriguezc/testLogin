﻿using System;
using Android.App;
using ClickiSalud.Mobile.Contracts.Services;
using ClickiSalud.Mobile.Droid.Renders;
using ClickiSalud.Mobile.UI.Views;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(ProviderLoginView), typeof(ProviderLoginRender))]
namespace ClickiSalud.Mobile.Droid.Renders
{
    public class ProviderLoginRender : PageRenderer
    {
        public ProviderLoginRender() { }

        private bool showLogin = true;
        private bool validateError = false;
    }
}