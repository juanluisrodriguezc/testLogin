﻿using System.Threading.Tasks;

namespace ClickiSalud.Mobile.Contracts.Services.General
{
    public interface IDialogService
    {
        Task ShowAlertAsync(string message);

        Task ShowAlertAsync(string message, string title);

        Task ShowAlertAsync(string message, string title, string buttonText);        
    }
}
