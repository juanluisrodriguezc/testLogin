﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using WebApi.Entities;
using WebApi.Services;
using WebApi.Services.Contracts;

namespace WebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var host = CreateWebHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;

                try
                {
                    if (!services.GetService<IConfiguration>().GetValue<bool>("UseMocks"))
                        DbInitializer.Seed(services.GetRequiredService<AppDbContext>(), services.GetRequiredService<ITelemetryService>());
                }
                catch (Exception ex)
                {
                    services.GetService<ITelemetryService>().ReportException(ex);
                }
            }

            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }
}
