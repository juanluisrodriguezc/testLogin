﻿using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.Contracts.ViewModels;
using ClickiSalud.Mobile.ViewModels.Base;
using MvvmCross.Commands;
using MvvmCross.Navigation;

namespace ClickiSalud.Mobile.ViewModels
{
    public class HomeViewModel : BaseViewModel,IHomeViewModel
    {
        public IMvxCommand ResetTextCommand => new MvxCommand(ResetText);
        private void ResetText()
        {
            Text = "Hello MvvmCross";
            dialogService.ShowAlertAsync("Hello", "Title", "Ok");            
        }

        public HomeViewModel(IDialogService dialogService, IMvxNavigationService navigationService) : base(dialogService, navigationService)
        {
        }

        private string _text = "Hello MvvmCross";
        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }
    }
}
