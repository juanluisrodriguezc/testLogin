﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using WebApi.Mappings;

namespace WebApi.Installers
{
    public class MapperInstaller : IInstaller
    {
        public void InstallServices(IServiceCollection services, IConfiguration configuration)
        {
            //Register automapper
            var mappingConfig = new MapperConfiguration(mc => mc.AddProfile<ClientMapProfile>());
            services.AddSingleton(mappingConfig.CreateMapper());
        }
    }
}
