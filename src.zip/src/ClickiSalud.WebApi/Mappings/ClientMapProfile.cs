﻿using AutoMapper;
using DTO;
using DTO.Request;
using DTO.Response;
using WebApi.Entities;

namespace WebApi.Mappings
{
    public class ClientMapProfile:Profile
    {
        /// <summary>
        /// Class constructor
        /// </summary>
        public ClientMapProfile()
        {
            
            CreateMap<Client, ClientDto>().ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Key));
            CreateMap<CreateUserRequest, User>();
            CreateMap<User, CreateUserResponse>();
        }
    }
}
