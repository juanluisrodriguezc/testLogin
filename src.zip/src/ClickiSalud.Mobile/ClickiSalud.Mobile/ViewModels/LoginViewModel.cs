﻿using System;
using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.Contracts.ViewModels;
using ClickiSalud.Mobile.Models.Enums;
using ClickiSalud.Mobile.ViewModels.Base;
using MvvmCross.Commands;
using MvvmCross.Navigation;
using Xamarin.Auth;
using Xamarin.Auth.Presenters;
using Xamarin.Forms;

namespace ClickiSalud.Mobile.ViewModels
{
    public class LoginViewModel : BaseViewModel, ILoginViewModel
    {
        public LoginViewModel(IDialogService dialogService, IMvxNavigationService navigationService) : base(dialogService, navigationService)
        {
        }

        public static EventHandler OnPresenter;
        LoginProvider loginProvider = new LoginProvider();
        OAuth2ProviderType ProviderName { get; set; }

        private string _userTxt = "Usuario";
        public string UserTxt
        {
            get { return _userTxt; }
            set { SetProperty(ref _userTxt, value); }
        }

        private string _passwordTxt = "Contraseña";
        public string PasswordTxt
        {
            get { return _passwordTxt; }
            set { SetProperty(ref _passwordTxt, value); }
        }

        public IMvxCommand LoginLocalCommand => new MvxCommand(() => LoginLocalOrProvider(OAuth2ProviderType.LOCAL));
        public IMvxCommand LoginFacebookCommand => new MvxCommand(() => LoginLocalOrProvider(OAuth2ProviderType.FACEBOOK));
        public IMvxCommand LoginGoogleCommand => new MvxCommand(() => LoginLocalOrProvider(OAuth2ProviderType.GOOGLE));

        public void LoginLocalOrProvider(OAuth2ProviderType oAuth2ProviderType)
        {
            try
            {
                if (oAuth2ProviderType == OAuth2ProviderType.LOCAL)
                {
                    dialogService.ShowAlertAsync("Usuario: " + _userTxt + " Pass: " + _passwordTxt, "LoginLocal", "Ok");
                }
                else
                {
                    ProviderName = oAuth2ProviderType;
                    LoginAuthenticate();
                }
            }
            catch (Exception ex)
            {
                dialogService.ShowAlertAsync(ex.ToString(), "Error", "Ok");
            }
        }

        void LoginAuthenticate()
        {
            OAuth2Authenticator oAuth2Authenticator = loginProvider.GetAuthenticator(ProviderName);

            oAuth2Authenticator.Completed += OAuth2Authenticator_Completed;
            oAuth2Authenticator.Error += OAuth2Authenticator_Error;

            var presenter = new OAuthLoginPresenter();
            presenter.Login(oAuth2Authenticator);
        }

        private void OAuth2Authenticator_Error(object sender, AuthenticatorErrorEventArgs e)
        {
            dialogService.ShowAlertAsync("", "Error", "Ok");
        }

        private async void OAuth2Authenticator_Completed(object sender, AuthenticatorCompletedEventArgs e)
        {
            if (e.IsAuthenticated)
            {
                var request = loginProvider.GetAuthenticatorRequest(ProviderName);
                request.Account = e.Account;
                var loginResponse = await request.GetResponseAsync();
                loginProvider.SetUserLogin(ProviderName, loginResponse.GetResponseText());
            }
            else
            {
                OAuth2Authenticator_Error(null,null);
                return;
            }
        }
    }
}
