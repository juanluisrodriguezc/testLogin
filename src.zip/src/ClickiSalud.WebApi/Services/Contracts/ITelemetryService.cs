﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Services.Contracts
{
    public interface ITelemetryService
    {
        /// <summary>
        /// Report exception to log service
        /// </summary>
        /// <param name="exception">Exception</param>
        /// <returns>Success report</returns>
        bool ReportException(Exception exception);
    }
}
