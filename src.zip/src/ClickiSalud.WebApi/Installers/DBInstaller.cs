﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using WebApi.Entities;
using WebApi.Services;
using WebApi.Services.Mocks;
using WebApi.Services.Contracts;

namespace WebApi.Installers
{
    public class DBInstaller : IInstaller
    {
        public void InstallServices(IServiceCollection services, IConfiguration configuration)
        {
            if (configuration.GetValue<bool>("UseMocks"))
            {
                //Register repositories
                services.AddTransient<IClientRepository, MockClientRepository>();
            }
            else
            {
                services.AddDbContext<AppDbContext>(options =>
                                                    options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));
                //Register repositories
                services.AddTransient<IClientRepository, ClientRepository>();
            }
            //services.AddSingleton<IMessageService, MessageService>();
            services.AddSingleton<IMessageService, CosmosMessageService>();
            services.AddSingleton<IUserService, MockUserService>();
        }
    }
}
