﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DTO.Request
{
    public class UpdatePostRequest
    {
        public string Name { get; set; }
    }
}
