﻿using System.Collections.Generic;
using WebApi.Entities;

namespace WebApi.Services.Contracts
{
    /// <summary>
    /// Client repository interface
    /// </summary>
    public interface IClientRepository
    {
        /// <summary>
        /// Get clients list
        /// </summary>
        /// <returns>Clients list</returns>
        IEnumerable<Client> GetClients();       
    }
}
