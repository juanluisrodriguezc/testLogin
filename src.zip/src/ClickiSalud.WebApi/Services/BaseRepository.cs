﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;
using WebApi.Services;
using WebApi.Services.Contracts;

namespace WebApi.Services
{
    /// <summary>
    /// Base repository class
    /// </summary>
    public abstract class BaseRepository
    {
        /// <summary>
        /// Database context
        /// </summary>
        protected readonly AppDbContext dbContext;

        /// <summary>
        /// Telemetry service
        /// </summary>
        protected readonly ITelemetryService telemetryService;

        /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="appDbContext">Database context</param>
        /// <param name="telemetryService">telemetry service</param>
        public BaseRepository(AppDbContext appDbContext, ITelemetryService telemetryService)
        {
            dbContext = appDbContext;
            this.telemetryService = telemetryService;
        }
    }

}
