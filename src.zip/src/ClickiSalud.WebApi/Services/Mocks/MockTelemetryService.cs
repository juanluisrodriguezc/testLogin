﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Services.Contracts;

namespace WebApi.Services.Mocks
{
    public class MockTelemetryService:ITelemetryService
    {
        public bool ReportException(Exception exception)
        {
            return true;
        }
    }
}
