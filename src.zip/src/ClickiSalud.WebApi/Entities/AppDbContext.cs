﻿using Microsoft.EntityFrameworkCore;

namespace WebApi.Entities
{
    /// <summary>
    /// Aplication database context
    /// </summary>
    public class AppDbContext : DbContext
    {
        /// <summary>
        /// Clients table
        /// </summary>
        public DbSet<Client> Clients { get; set; }

        /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="options">context options</param>
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}
