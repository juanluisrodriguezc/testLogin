﻿using Cosmonaut;
using System.Collections.Generic;
using System.Linq;
using WebApi.Entities;
using WebApi.Services.Contracts;

namespace WebApi.Services
{
    public class CosmosMessageService : IMessageService
    {
        private readonly ICosmosStore<Message> _cosmosStore;
        public CosmosMessageService(ICosmosStore<Message> cosmosStore)
        {
            _cosmosStore = cosmosStore;
        }

        public bool CreateMessage(Message message)
        {
            return _cosmosStore.AddAsync(message).Result.IsSuccess;
        }

        public bool DeleteMessage(string messageId)
        {
            return _cosmosStore.RemoveByIdAsync(messageId, messageId).Result.IsSuccess;
        }

        public Message GetMessage(string messageId)
        {
            return _cosmosStore.FindAsync(messageId, messageId).Result;
        }

        public List<Message> GetMessages()
        {
            return _cosmosStore.Query().ToList();
        }

        public bool UpdateMessage(Message messageToUpdate)
        {
            return _cosmosStore.UpdateAsync(messageToUpdate).Result.IsSuccess;
        }
    }
}
