﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DTO.Enums;
using DTO.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using WebApi.Contracts;

namespace WebApi.Controllers.V1
{
    public class CatalogsController : Controller
    {
        string connectionString;
        public CatalogsController(IConfiguration configuration)
        {
            connectionString = configuration["Blobstorage:connectionString"];
        }
        [HttpGet(ApiRoutes.Catalogs.Get)]
        public IActionResult GetCatalog([FromRoute] CatalogEnum catalog)
        {
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);
                CloudBlobClient serviceClient = storageAccount.CreateCloudBlobClient();
                CloudBlobContainer container = serviceClient.GetContainerReference($"catalogos");

                //container.CreateIfNotExistsAsync();

                BlobContainerPermissions permissions = new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                };
                container.SetPermissionsAsync(permissions);

                var blob = container.GetBlockBlobReference($"{catalog.ToString()}.json");

                var contents = blob.DownloadTextAsync().Result;
                
                return Ok(JsonConvert.DeserializeObject<Preguntas>(contents));
            }
            catch (AggregateException ex)
            {
                //remove exception message on prod
                return NotFound(ex.Message);
            }
        }
    }
}