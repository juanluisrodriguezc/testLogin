﻿using MvvmCross.Forms.Views;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace ClickiSalud.Mobile.UI.Views.Base
{
    public abstract class BaseContentPage : MvxContentPage
    {
        public BaseContentPage()
        {
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
        }
    }
}
