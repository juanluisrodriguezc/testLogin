﻿using System;
using System.Collections.Generic;
using WebApi.Entities;
using WebApi.Services.Contracts;

namespace WebApi.Services.Mocks
{
    public class MockClientRepository : IClientRepository
    {
        private List<Client> clientList;

        public MockClientRepository()
        {
            clientList = new List<Client>();

            clientList.Add(new Client { Key = new Guid("04200baa-e70a-4542-b5bb-2812bcb95c9f"), Id = 1, Name = "RB" });
            clientList.Add(new Client { Key = new Guid("0e4a15fb-e89b-40f6-8073-a6747bc73d85"), Id = 2, Name = "Cargo algo" });
            clientList.Add(new Client { Key = new Guid("0fd24979-c85e-43b7-9a9e-a37addcfd45a"), Id = 3, Name = "bSide" });
        }

        public IEnumerable<Client> GetClients()
        {
            return clientList;
        }
    }

}
