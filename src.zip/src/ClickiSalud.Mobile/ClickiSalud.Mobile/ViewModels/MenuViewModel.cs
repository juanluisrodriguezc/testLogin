﻿using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.ViewModels.Base;
using MvvmCross.Navigation;

namespace ClickiSalud.Mobile.ViewModels
{
    public class MenuViewModel : BaseViewModel
    {
        public MenuViewModel(IDialogService dialogService, IMvxNavigationService navigationService) : base(dialogService, navigationService)
        {

        }
    }
}
