﻿using ClickiSalud.Mobile.UI.Views.Base;
using MvvmCross.Forms.Presenters.Attributes;

namespace ClickiSalud.Mobile.UI.Views
{
    [MvxMasterDetailPagePresentation(MasterDetailPosition.Detail, NoHistory = true)]
    public partial class HomeView : BaseContentPage
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}