﻿using System;
using System.Threading.Tasks;
using Android.App;
using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.Resources;
using MvvmCross;
using MvvmCross.Platforms.Android;

namespace ClickiSalud.Mobile.Droid.Services
{
    class DialogService : IDialogService
    {
        protected Activity CurrentActivity =>
            Mvx.IoCProvider.Resolve<IMvxAndroidCurrentTopActivity>().Activity;

        public Task ShowAlertAsync(string message)
        {
            return Task.Run(() => Alert(message, AppResources.ApplicationName, AppResources.Ok));
        }

        public Task ShowAlertAsync(string message, string title)
        {
            return Task.Run(() => Alert(message, title, AppResources.Ok));
        }

        public Task ShowAlertAsync(string message, string title, string buttonText)
        {
            return Task.Run(() => Alert(message, title, buttonText));
        }

        private void Alert(string message, string title, string okButton)
        {
            Application.SynchronizationContext.Post(ignored =>
            {
                var builder = new AlertDialog.Builder(CurrentActivity);
                builder.SetIconAttribute
                    (Android.Resource.Attribute.AlertDialogIcon);
                builder.SetTitle(title);
                builder.SetMessage(message);
                builder.SetPositiveButton(okButton, delegate { });
                builder.Create().Show();
            }, null);
        }
    }
}