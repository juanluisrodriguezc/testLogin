﻿using ClickiSalud.Mobile.Models;
using ClickiSalud.Mobile.Models.Enums;
using Xamarin.Auth;

namespace ClickiSalud.Mobile.Contracts.Services.General
{
    public interface ILoginProvider
    {
        LoginProviderRequest FillLoginProviderRequest();

        OAuth2Authenticator GetAuthenticator(OAuth2ProviderType providerType);

        OAuth2Request GetAuthenticatorRequest(OAuth2ProviderType providerType);

        LoginProviderResponse SetUserLogin(OAuth2ProviderType providerType, string response);
    }
}