﻿using ClickiSalud.Mobile.Contracts.Services.General;
using MvvmCross;
using System;
using System.Collections.Generic;

namespace ClickiSalud.Mobile.Extensions
{
    /// <summary>
    /// Exception class extension
    /// </summary>
    public static class ExceptionExtension
    {
        /// <summary>
        /// Track exception
        /// </summary>
        /// <param name="value">Exception to track</param>
        public static void Track(this Exception value)
        {
            Mvx.IoCProvider.Resolve<IAppCenterService>().TrackError(value);
        }

        /// <summary>
        /// Track exception
        /// </summary>
        /// <param name="value">Exception to track</param>
        /// <param name="parameters">Exception parameters</param>
        public static void Track(this Exception value, IDictionary<string, string> parameters)
        {
            Mvx.IoCProvider.Resolve<IAppCenterService>().TrackError(value, parameters);
        }
    }
}
