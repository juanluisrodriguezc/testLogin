﻿namespace ClickiSalud.Mobile.Models
{
    /// <summary>
    /// Configuration values
    /// </summary>
    public class ConfigurationValue
    {
        /// <summary>
        /// Application use mock data
        /// </summary>
        public bool UseMocks { get; set; }

        /// <summary>
        /// Api Service Endpoint
        /// </summary>
        public string ServiceEndpoint { get; set; }

        /// <summary>
        /// Android App Center App Secret
        /// </summary>
        public string AppCenterAndroidAppSecret { get; set; }

        /// <summary>
        /// iOS App Center App Secret
        /// </summary>
        public string AppCenterIOSAppSecret { get; set; }
    }
}
