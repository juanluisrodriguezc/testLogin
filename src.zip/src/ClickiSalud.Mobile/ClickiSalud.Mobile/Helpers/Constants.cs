﻿namespace ClickiSalud.Mobile.Helpers
{
    /// <summary>
    /// Constants
    /// </summary>
    public class Constants
    {
        /// <summary>
        /// App center start string format
        /// </summary>
        public const string AppCenterSecretFormat = "ios={0};android={1}";
    }
}
