﻿using ClickiSalud.Mobile.Models;
using MvvmCross;
using Newtonsoft.Json;
using System.IO;
using System.Reflection;

namespace ClickiSalud.Mobile.Helpers.Configuration
{
    /// <summary>
    /// Application configuration
    /// </summary>
    [Preserve(AllMembers = true)]
    public static class AppConfiguration
    {
        #region Properties
       
        /// <summary>
        /// Configuration values
        /// </summary>
        public static ConfigurationValue Values { get; private set; }

        /// <summary>
        /// Configuration file name
        /// </summary>
        private const string CONFIG_FILE_NAME = "Configuration.json";

        #endregion Properties

        #region Constructor

        /// <summary>
        /// Class constructor
        /// </summary>
        static AppConfiguration()
        {
            InitializeValues();
        }

        #endregion Constructor

        #region Methods

        /// <summary>
        /// Initialize Values
        /// </summary>
        private static void InitializeValues()
        {
            var assembly = typeof(AppConfiguration).GetTypeInfo().Assembly;
            var stream = assembly.GetManifestResourceStream($"ClickiSalud.Mobile.Helpers.Configuration.{CONFIG_FILE_NAME}");

            using (var reader = new StreamReader(stream))
            {
                Values = JsonConvert.DeserializeObject<ConfigurationValue>(reader.ReadToEnd());
            }
        }

        #endregion Methods
    }
}
