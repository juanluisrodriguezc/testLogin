﻿using System;
using System.Globalization;
using MvvmCross.Converters;

namespace ClickiSalud.Mobile.UI.Converters
{
    /// <summary>
    /// Inverse bool value
    /// </summary>
    public class InverseBoolConverter : MvxValueConverter<bool, bool>
    {        
        protected override bool Convert(bool value, Type targetType, object parameter, CultureInfo culture)
        {
            return !value;
        }
    }
}
