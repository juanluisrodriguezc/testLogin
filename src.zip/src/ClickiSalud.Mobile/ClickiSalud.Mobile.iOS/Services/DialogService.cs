﻿using System.Threading.Tasks;
using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.Resources;
using UIKit;

namespace ClickiSalud.Mobile.iOS.Services
{
    public class DialogService : IDialogService
    {
        public Task ShowAlertAsync(string message)
        {
            return InternalShowAlert(message, AppResources.ApplicationName, AppResources.Ok);
        }

        public Task ShowAlertAsync(string message, string title)
        {
            return InternalShowAlert(message, title, AppResources.Ok);
        }

        public Task ShowAlertAsync(string message, string title, string buttonText)
        {
            return InternalShowAlert(message, title, buttonText);
        }

        private Task InternalShowAlert(string message, string title, string buttonText)
        {
            return Task.Run(() =>
                UIApplication.SharedApplication.InvokeOnMainThread(() =>
                {
                    new UIAlertView(title, message, null, buttonText).Show();
                }));
        }
    }
}