﻿using ClickiSalud.Mobile.Contracts.Services.General;
using System;
using System.Collections.Generic;

namespace ClickiSalud.Mobile.Mocks.Services.General
{
    public class MockAppCenterService : IAppCenterService
    {
        public bool Started => true;

        public void Start()
        {
        }        

        public void TrackError(Exception exception)
        {            
        }

        public void TrackError(Exception exception, IDictionary<string, string> properties)
        {            
        }
    }
}
