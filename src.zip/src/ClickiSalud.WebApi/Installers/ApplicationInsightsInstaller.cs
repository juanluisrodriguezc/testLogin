﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using WebApi.Services;
using WebApi.Services.Contracts;
using WebApi.Services.Mocks;

namespace WebApi.Installers
{
    public class ApplicationInsightsInstaller : IInstaller
    {
        public void InstallServices(IServiceCollection services, IConfiguration configuration)
        {
            if (configuration.GetValue<bool>("UseMocks"))
            {
                //Register services
                services.AddSingleton<ITelemetryService>(new MockTelemetryService());
            }
            else
            {
                //Register services
                services.AddApplicationInsightsTelemetry();
                services.AddSingleton<ITelemetryService>(new TelemetryService());
            }
        }
    }
}
