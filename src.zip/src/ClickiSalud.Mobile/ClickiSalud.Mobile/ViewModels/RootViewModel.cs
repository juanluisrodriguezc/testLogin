﻿using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.ViewModels.Base;
using MvvmCross.Navigation;
using MvvmCross.ViewModels;
using System.Threading.Tasks;

namespace ClickiSalud.Mobile.ViewModels
{
    public class RootViewModel : BaseViewModel
    {        
        public RootViewModel(IDialogService dialogServoce, IMvxNavigationService navigationService) : base (dialogServoce, navigationService)
        {            
        }

        public override void ViewAppearing()
        {
            base.ViewAppearing();
            MvxNotifyTask.Create(async () => await InitializeViewModels());
        }

        private async Task InitializeViewModels()
        {
            await navigationService.Navigate<MenuViewModel>();
            await navigationService.Navigate<HomeViewModel>();
        }
    }
}
