﻿using ClickiSalud.Mobile.UI.Views.Base;
using MvvmCross.Forms.Presenters.Attributes;

namespace ClickiSalud.Mobile.UI.Views
{
    [MvxMasterDetailPagePresentation(MasterDetailPosition.Master)]
    public partial class MenuView : BaseContentPage
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}