﻿using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.iOS.Services;
using Foundation;
using MvvmCross;
using MvvmCross.Forms.Platforms.Ios.Core;
using MvvmCross.Platforms.Ios.Core;
using MvvmCross.ViewModels;
using UIKit;

namespace ClickiSalud.Mobile.iOS
{
    // The UIApplicationDelegate for the application. This class is responsible for launching the 
    // User Interface of the application, as well as listening (and optionally responding) to 
    // application events from iOS.
    [Register("AppDelegate")]
    public partial class AppDelegate : MvxFormsApplicationDelegate<MvxFormsIosSetup<App, UI.App>, App, UI.App>
    {
        public override UIWindow Window { get; set; }       

        public override bool FinishedLaunching(UIApplication uiApplication, NSDictionary launchOptions)
        {
            global::Xamarin.Auth.Presenters.XamarinIOS.AuthenticationConfiguration.Init();

            Window = new UIWindow(UIScreen.MainScreen.Bounds);

            MvxIosSetupSingleton.EnsureSingletonAvailable(this, Window)
                                .EnsureInitialized();        

            RegisterServices();

            return base.FinishedLaunching(uiApplication, launchOptions);
        }

        private void RegisterServices()
        {
            Mvx.IoCProvider.RegisterSingleton<IDialogService>(() => new DialogService());
        }
    }
}
