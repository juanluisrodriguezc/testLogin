﻿using System;
using Microsoft.AspNetCore.Mvc;
using WebApi.Contracts;
using DTO.Request;
using DTO.Response;
using WebApi.Services.Contracts;
using WebApi.Entities;

namespace WebApi.Controllers.V1
{
    public class MessagesController : Controller
    {
        private readonly IMessageService _messageService;
        
        public MessagesController(IMessageService messageService)
        {
            _messageService = messageService;
        }

        [HttpGet(ApiRoutes.Messages.GetAll)]
        public IActionResult GetAll()
        {
            return Ok(_messageService.GetMessages());
        }

        [HttpGet(ApiRoutes.Messages.Get)]
        public IActionResult Get([FromRoute] Guid messageId)
        {
            var result = _messageService.GetMessage(messageId.ToString());
            if (result == null)
                return NotFound();
            return Ok(result);
        }

        [HttpPut(ApiRoutes.Messages.Update)]
        public IActionResult Update([FromRoute] string messageId, [FromBody] UpdatePostRequest updatePostRequest)
        {
            var message = new Message()
            {
                Id = messageId,
                Name = updatePostRequest.Name
            };
            var updated = _messageService.UpdateMessage(message);
            if (updated)
                return Ok(message);
            return NotFound();
        }

        [HttpPost(ApiRoutes.Messages.Create)]
        public IActionResult Create([FromBody] CreateMessageRequest message)
        {
            message.Id = (string.IsNullOrEmpty(message.Id) ? Guid.NewGuid().ToString() : message.Id);
            _messageService.CreateMessage(new Message()
            {
                Id = message.Id,
                Name = message.Name
            });
            var baseUrl = HttpContext.Request.Scheme + "://" + HttpContext.Request.Host.ToUriComponent();
            var locationUrl = baseUrl + "/" + ApiRoutes.Messages.Get.Replace("{messageId}", message.Id.ToString());
            var response = new CreateMessageResponse()
            {
                Id = message.Id,
                Name = message.Name
            };
            return Created(locationUrl, response);
        }

        [HttpDelete(ApiRoutes.Messages.Delete)]
        public IActionResult Delete([FromRoute] Guid messageId)
        {
            var isDeleted = _messageService.DeleteMessage(messageId.ToString());
            if (isDeleted)
                return NoContent();
            return NotFound();
        }
    }
}