﻿using System.Collections.Generic;
using WebApi.Entities;

namespace WebApi.Services.Contracts
{
    public interface IMessageService
    {
        List<Message> GetMessages();
        Message GetMessage(string messageId);
        bool UpdateMessage(Message messageToUpdate);
        bool DeleteMessage(string messageId);
        bool CreateMessage(Message message);
    }
}
