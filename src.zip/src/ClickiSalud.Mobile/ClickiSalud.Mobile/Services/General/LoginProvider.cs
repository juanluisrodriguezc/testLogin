﻿using System;
using ClickiSalud.Mobile.Models;
using ClickiSalud.Mobile.Models.Enums;
using Newtonsoft.Json;
using Xamarin.Auth;

namespace ClickiSalud.Mobile.Contracts.Services.General
{
    public class LoginProvider : ILoginProvider
    {
        public object UserLogin { get; set; }

        public LoginProviderRequest FillLoginProviderRequest()
        {
            LoginProviderRequest loginProviderRequest = new LoginProviderRequest();

            loginProviderRequest.RequestFacebook = new LoginRequestFacebook();
            loginProviderRequest.RequestFacebook.AppId = "394742057893990";

            //loginProviderRequest.RequestFacebook.AppId = "2583977138333606";

            loginProviderRequest.RequestGoogle = new LoginRequestGoogle();
            loginProviderRequest.RequestGoogle.ClientId = "";
            loginProviderRequest.RequestGoogle.ClientSecret = "";
            loginProviderRequest.RequestGoogle.UriSuccess = "";

            return loginProviderRequest;
        }

        public OAuth2Authenticator GetAuthenticator(OAuth2ProviderType providerType)
        {
            LoginProviderRequest loginProviderRequest = FillLoginProviderRequest();
            OAuth2Authenticator auth = null;

            switch (providerType)
            {
                case OAuth2ProviderType.FACEBOOK:
                    {
                        auth = new OAuth2Authenticator(
                                clientId: loginProviderRequest.RequestFacebook.AppId,
                                scope: "email",
                                authorizeUrl: new Uri("https://m.facebook.com/dialog/oauth/"),
                                redirectUrl: new Uri("https://www.facebook.com/connect/login_success.html")
                        );
                        break;
                    }

                case OAuth2ProviderType.GOOGLE:
                    {

                        auth = new OAuth2Authenticator(
                            loginProviderRequest.RequestGoogle.ClientId,
                            loginProviderRequest.RequestGoogle.ClientSecret,
                            "https://www.googleapis.com/auth/userinfo.email",
                            new Uri("https://accounts.google.com/o/oauth2/auth"),
                            new Uri(loginProviderRequest.RequestGoogle.UriSuccess),
                            new Uri("https://accounts.google.com/o/oauth2/token")
                        );
                        break;
                    }
            }

            return auth;
        }

        public OAuth2Authenticator GetAuthenticator(string providerName)
        {
            throw new NotImplementedException();
        }

        public OAuth2Request GetAuthenticatorRequest(OAuth2ProviderType providerType)
        {
            OAuth2Request request = null;
            switch (providerType)
            {
                case OAuth2ProviderType.FACEBOOK:
                    request = new OAuth2Request("GET", new Uri("https://www.googleapis.com/oauth2/v2/userinfo"), null, null);
                    break;

                case OAuth2ProviderType.GOOGLE:
                    request = new OAuth2Request("GET", new Uri("https://graph.facebook.com/me?fields=name,email,picture,cover,birthday"), null, null);
                    break;
            }
            return request;
        }

        public LoginProviderResponse SetUserLogin(OAuth2ProviderType providerType, string response)
        {
            LoginProviderResponse loginProviderResponse = new LoginProviderResponse();
            loginProviderResponse.ProviderType = providerType;
            
            switch (providerType)
            {
                case OAuth2ProviderType.FACEBOOK:
                    loginProviderResponse.FacebookLogin = new FacebookLoginModel();
                    loginProviderResponse.FacebookLogin = JsonConvert.DeserializeObject<FacebookLoginModel>(response);
                    break;

                case OAuth2ProviderType.GOOGLE:
                    loginProviderResponse.GoogleLogin = new GoogleLoginModel();
                    loginProviderResponse.GoogleLogin = JsonConvert.DeserializeObject<GoogleLoginModel>
                        (response.Replace("\n", "").Replace("\"", "'"));
                    break;
            }

            return loginProviderResponse;
        }
    }
}