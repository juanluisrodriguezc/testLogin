﻿using Microsoft.ApplicationInsights;
using System;
using System.Diagnostics;
using WebApi.Services.Contracts;

namespace WebApi.Services
{
    public class TelemetryService : ITelemetryService
    {
        /// <summary>
        /// Telemetry client
        /// </summary>
        private TelemetryClient telemetryClient;

        /// <summary>
        /// Class constructor
        /// </summary>
        public TelemetryService()
        {
            telemetryClient = new TelemetryClient();
        }

        /// <summary>
        /// Report exception to log service
        /// </summary>
        /// <param name="exception">Exception</param>
        /// <returns>Success report</returns>
        public bool ReportException(Exception exception)
        {
            try
            {
                telemetryClient.TrackException(exception);
                return true;
            }
            catch (Exception ex)
            {
                Trace.TraceError(ex.ToString());
                return false;
            }
        }
    }

}
