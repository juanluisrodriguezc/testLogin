﻿namespace DTO.Response
{
    public class CreateMessageResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
