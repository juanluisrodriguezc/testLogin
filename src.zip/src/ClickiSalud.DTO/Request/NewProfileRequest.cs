﻿using DTO.Enums;

namespace DTO.Request
{
    public class NewProfileRequest
    {
        public string email { get; set; }
        public ProviderEnum provider { get; set; }
    }
}
