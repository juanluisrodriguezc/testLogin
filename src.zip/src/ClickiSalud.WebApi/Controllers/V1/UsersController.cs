﻿using AutoMapper;
using DTO.Request;
using Microsoft.AspNetCore.Mvc;
using WebApi.Contracts;
using DTO.Response;
using WebApi.Entities;
using WebApi.Services.Contracts;

namespace WebApi.Controllers.V1
{
    public class UsersController : Controller
    {
        private readonly IUserService _userService;
        private readonly IMapper _mapper;


        public UsersController(IUserService userService, IMapper mapper)
        {
            _userService = userService;
            _mapper = mapper;
        }

        [HttpPost(ApiRoutes.Users.Create)]
        public IActionResult Create([FromBody] CreateUserRequest user)
        {
            var result = _userService.CreateUser(_mapper.Map<User>(user));
            var baseUrl = HttpContext.Request.Scheme + "://" + HttpContext.Request.Host.ToUriComponent();
            var locationUrl = baseUrl + "/" + ApiRoutes.Messages.Get.Replace("{userId}", result.ToString());
            return Created(locationUrl, result);
        }
        [HttpPost(ApiRoutes.Users.ValidateUser)]
        public IActionResult ValidateUser([FromBody] ValidateUserRequest request)
        {
            var result = _userService.ValidateUser(request.user, request.password);
            if (result != null)
                return Ok(_mapper.Map<CreateUserResponse>(result));
            return NotFound();
        }
        [HttpPost(ApiRoutes.Users.ValidateAccount)]
        public IActionResult ValidateAccount([FromBody] ValidateAccountRequest request)
        {
            var result = _userService.ValidateAccount(request.email, request.keyToMail);
            if (result)
                return Ok();
            return NotFound();
        }
        [HttpGet(ApiRoutes.Users.Forgot)]
        public IActionResult ForgotPass([FromRoute]string email)
        {
            var result = _userService.ForgotPass(email);
            if (result)
                return Ok(result);
            return NotFound(email);
        }
        [HttpPost(ApiRoutes.Users.CreateNewProfile)]
        public IActionResult CreateNewProfile(NewProfileRequest request)
        {
            return Ok(_userService.CreateNewProfile(request.email, request.provider));
        }

    }
}