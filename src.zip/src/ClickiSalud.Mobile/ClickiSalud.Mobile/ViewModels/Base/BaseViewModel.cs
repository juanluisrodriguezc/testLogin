﻿using ClickiSalud.Mobile.Contracts.Services.General;
using MvvmCross.Navigation;
using MvvmCross.ViewModels;

namespace ClickiSalud.Mobile.ViewModels.Base
{
    /// <summary>
    /// Base view model class
    /// </summary>
    public abstract class BaseViewModel : MvxViewModel
    {
        /// <summary>
        /// The app is busy
        /// </summary>
        private bool isBusy;

        /// <summary>
        /// The app is busy
        /// </summary>
        public bool IsBusy
        {
            get => isBusy;

            set
            {
                isBusy = value;
                RaisePropertyChanged(() => IsBusy);
            }
        }

        /// <summary>
        /// Dialog service
        /// </summary>
        protected readonly IDialogService dialogService;

        /// <summary>
        /// Navigation service
        /// </summary>
        protected readonly IMvxNavigationService navigationService;

        /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="dialogService">Dialog service</param>
        /// <param name="navigationService">Mvx navigation service</param>
        public BaseViewModel(IDialogService dialogService, IMvxNavigationService navigationService)
        {
            this.dialogService = dialogService;
            this.navigationService = navigationService;
        }
    }

    /// <summary>
    /// Base view model class
    /// </summary>
    public abstract class BaseViewModel<TParameter> : MvxViewModel<TParameter>
    {
        /// <summary>
        /// Parameter
        /// </summary>
        private TParameter parameter;

        /// <summary>
        /// The app is busy
        /// </summary>
        private bool isBusy;

        /// <summary>
        /// The app is busy
        /// </summary>
        public bool IsBusy
        {
            get => isBusy;

            set
            {
                isBusy = value;
                RaisePropertyChanged(() => IsBusy);
            }
        }

        /// <summary>
        /// Dialog service
        /// </summary>
        protected readonly IDialogService dialogService;

        /// <summary>
        /// Navigation service
        /// </summary>
        protected readonly IMvxNavigationService navigationService;

        /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="dialogService">Dialog service</param>
        /// <param name="navigationService">Mvx navigation service</param>
        public BaseViewModel(IDialogService dialogService, IMvxNavigationService navigationService)
        {
            this.dialogService = dialogService;
            this.navigationService = navigationService;
        }

        /// <summary>
        /// Prepare parameter
        /// </summary>
        /// <param name="parameter">Parameter</param>
        public override void Prepare(TParameter parameter)
        {
            this.parameter = parameter;
        }
    }
}
