﻿using System.Threading.Tasks;
using ClickiSalud.Mobile.Contracts.Services.General;
using ClickiSalud.Mobile.Helpers.Configuration;
using ClickiSalud.Mobile.Mocks.Services.General;
using ClickiSalud.Mobile.Services.General;
using ClickiSalud.Mobile.ViewModels;
using MvvmCross;
using MvvmCross.ViewModels;

namespace ClickiSalud.Mobile
{
    /// <summary>
    /// Mvx application
    /// </summary>
    public class App : MvxApplication
    {
        /// <summary>
        /// Initialize application
        /// </summary>
        public override void Initialize()
        {
            RegisterRepositories();
            RegisterServices();            

            Mvx.IoCProvider.Resolve<IAppCenterService>().Start();
            RegisterAppStart<RootViewModel>();
        }        

        /// <summary>
        /// Register repositories
        /// </summary>
        private void RegisterRepositories()
        {
            if (AppConfiguration.Values.UseMocks)
            {                   
            }
            else
            {
            }
        }

        /// <summary>
        /// Register services
        /// </summary>
        private void RegisterServices()
        {
            if (AppConfiguration.Values.UseMocks)
            {
                Mvx.IoCProvider.RegisterSingleton<IAppCenterService>(new MockAppCenterService());                
            }
            else
            {
                Mvx.IoCProvider.RegisterSingleton<IAppCenterService>(new AppCenterService());
            }
        }
    }
}
