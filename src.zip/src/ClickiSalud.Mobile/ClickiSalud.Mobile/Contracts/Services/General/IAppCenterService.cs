﻿using System;
using System.Collections.Generic;

namespace ClickiSalud.Mobile.Contracts.Services.General
{
    /// <summary>
    /// App center service interface
    /// </summary>
    public interface IAppCenterService
    {
        /// <summary>
        /// Service started
        /// </summary>
        bool Started { get; }

        /// <summary>
        /// Start app center service
        /// </summary>
        void Start();

        /// <summary>
        /// Track exception error
        /// </summary>
        /// <param name="exception">Exception</param>
        void TrackError(Exception exception);

        /// <summary>
        /// Track exception error
        /// </summary>
        /// <param name="exception">Exception</param>
        /// <param name="properties">Exception properties</param>
        void TrackError(Exception exception, IDictionary<string, string> properties);
    }
}
