﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Contracts
{
    public static class ApiRoutes
    {
        public const string Root = "api";
        public const string Version = "v1";
        public const string Base = Root + "/" + Version;
        public static class Messages
        {
            public const string GetAll = Base + "/messages";
            public const string Get = Base + "/messages/{messageId}";
            public const string Delete = Base + "/messages/{messageId}";
            public const string Update = Base + "/messages/{messageId}";
            public const string Create = Base + "/messages";
        }

        public static class Catalogs
        {
            public const string Get = Base + "/catalogs/{catalog}";
        }
        public static class Users
        {
            public const string Forgot = Base + "/users/{email}";
            public const string ValidateUser = Base + "/ValidateUser";
            public const string ValidateAccount = Base + "/ValidateAccount";
            public const string Create = Base + "/users";
            public const string CreateNewProfile = Base + "/CreateNewProfile"; 
        }
    }
}
