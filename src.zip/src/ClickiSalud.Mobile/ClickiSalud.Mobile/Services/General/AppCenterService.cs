﻿using ClickiSalud.Mobile.Helpers;
using ClickiSalud.Mobile.Helpers.Configuration;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using IAppCenterService = ClickiSalud.Mobile.Contracts.Services.General.IAppCenterService;

namespace ClickiSalud.Mobile.Services.General
{
    /// <summary>
    /// App center service
    /// </summary>
    public class AppCenterService : IAppCenterService
    {
        /// <summary>
        /// Service started
        /// </summary>
        public bool Started { get; private set; }

        /// <summary>
        /// Start app center service
        /// </summary>
        public void Start()
        {
            if (Started)
            {
                try
                {
                    AppCenter.Start(string.Format(Constants.AppCenterSecretFormat,
                                              AppConfiguration.Values.AppCenterIOSAppSecret,
                                              AppConfiguration.Values.AppCenterAndroidAppSecret),
                                    typeof(Analytics),
                                    typeof(Crashes));

                    Started = true;
                }
                catch (Exception ex)
                {
                    Started = false;
                    Trace.TraceError(ex.ToString());
                }
            }                       
        }

        /// <summary>
        /// Track exception error
        /// </summary>
        /// <param name="exception">Exception</param>
        public void TrackError(Exception exception)
        {
            if(Started)
            Crashes.TrackError(exception);
        }

        /// <summary>
        /// Track exception error
        /// </summary>
        /// <param name="exception">Exception</param>
        /// <param name="properties">Exception properties</param>
        public void TrackError(Exception exception, IDictionary<string,string> properties)
        {
            if(Started)
            Crashes.TrackError(exception, properties);
        }        
    }
}
