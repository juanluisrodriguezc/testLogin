﻿using System;
using System.Collections.Generic;
using WebApi.Entities;
using WebApi.Services.Contracts;

namespace WebApi.Services
{
    /// <summary>
    /// Client repository
    /// </summary>
    public class ClientRepository : BaseRepository, IClientRepository
    {
        /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="appDbContext">Database context</param>
        /// <param name="telemetryService">telemetry service</param>
        public ClientRepository(AppDbContext appDbContext, ITelemetryService telemetryService) : base(appDbContext, telemetryService)
        {
        }

        /// <summary>
        /// Get all clients
        /// </summary>
        /// <returns>Client list</returns>
        public IEnumerable<Client> GetClients()
        {
            try
            {
                return dbContext.Clients;
            }
            catch(Exception ex)
            {
                telemetryService.ReportException(ex);
                throw;
            }            
        }
    }
}
