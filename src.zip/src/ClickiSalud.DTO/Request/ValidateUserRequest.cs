﻿namespace DTO.Request
{
    public class ValidateUserRequest
    {
        public string user { get; set; }
        public string password { get; set; }
    }
}
