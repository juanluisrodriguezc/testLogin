﻿using System;
using ClickiSalud.Mobile.Models.Enums;

namespace ClickiSalud.Mobile.Models
{
    public class LoginProviderRequest
    {
        public OAuth2ProviderType OAuth2ProviderType { get; set; }
        public LoginRequestFacebook RequestFacebook { get; set; }
        public LoginRequestGoogle RequestGoogle { get; set; }
    }

    public class LoginRequestFacebook
    {
        public string AppId { get; set; }
    }

    public class LoginRequestGoogle
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string UriSuccess { get; set; }
    }

}
