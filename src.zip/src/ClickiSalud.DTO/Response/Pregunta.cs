﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Response
{
    public class Pregunta
    {
        public int numero { get; set; }
        public string texto { get; set; }
        public List<string> respuestas { get; set; }
    }
}
